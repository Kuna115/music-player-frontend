# Web Music Player
A Progressive Web Music Player built with HTML and CSS.

<h1>          Screenshot  </h>
    
<p> 
<br>

<div id="mydiv">
<img   src="https://raw.githubusercontent.com/amitozs999/Web-Music-Player/master/img/musicplayerscreenshot.jpg" width="1300" height="500"/>
</div>



<p>



